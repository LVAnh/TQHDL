import generate from './generic.model.js';
import db from '../utils/db.js';

let userModel = generate('products', 'product_id');
export default userModel
