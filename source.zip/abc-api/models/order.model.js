import generate from './generic.model.js';
import db from '../utils/db.js';

let orderModel = generate('orders', 'order_id');
export default orderModel
