import generate from './generic.model.js';
export default generate('categories', 'category_id');
