import {
    Container,
    SimpleGrid,
    Image,
    Flex,
    Heading,
    Text,
    Stack,
    StackDivider,
    Icon,
    useColorModeValue,
} from '@chakra-ui/react';
import {IoAnalyticsSharp} from 'react-icons/io5';
import Chart from "./chart";
import {useEffect, useState} from "react";
import api from "../api";


const Feature = ({text, icon, iconBg, onClick}) => {
    return (
        <Stack direction={'row'} align={'center'} onClick={onClick}>
            <Flex
                w={8}
                h={8}
                align={'center'}
                justify={'center'}
                rounded={'full'}
                bg={iconBg}>
                {icon}
            </Flex>
            <Text fontWeight={600}>{text}</Text>
        </Stack>
    );
};

export default function Home() {
    const [typeChart,setTypeChart] = useState(0);
    const [data,setData] = useState([]);
    const [categories,setCategories] = useState([]);

    useEffect(()=>{
        api.get('/categories').then(res=>{
            setCategories(res.data)
        })
    },[])
    function getCategoryName(id){
        let name = ""
        categories.forEach(cat=>{
            if(cat.category_id === id){
                name = cat.name
            }
        })
        return name
    }
    function getProducts(){
        api.get(`/products/`).then(res=>{
            const result = [];
            res.data.forEach(pro=>{
                const index = result.findIndex(cat=>cat.category_id===pro.category_id)
                if(index>=0){
                    result[index] = {
                        ...result[index],
                        sales: (result[index].sales+pro.sales)
                    }
                }else {
                    result.push({
                        category_id: pro.category_id,
                        category_name: getCategoryName(pro.category_id),
                        sales:pro.sales
                    })
                }
            })
            setData(result)
        })
    }

    const alphabet = [
        {"letter": "A", "frequency": 0.08167},
        {"letter": "B", "frequency": 0.01492},
        {"letter": "C", "frequency": 0.02782},
        {"letter": "D", "frequency": 0.04253},
        {"letter": "E", "frequency": 0.12702},
        {"letter": "F", "frequency": 0.02288},
        {"letter": "G", "frequency": 0.02015},
        {"letter": "H", "frequency": 0.06094},
        {"letter": "I", "frequency": 0.06966},
        {"letter": "J", "frequency": 0.00153},
        {"letter": "K", "frequency": 0.00772},
        {"letter": "L", "frequency": 0.04025},
        {"letter": "M", "frequency": 0.02406},
        {"letter": "N", "frequency": 0.06749},
        {"letter": "O", "frequency": 0.07507},
        {"letter": "P", "frequency": 0.01929},
        {"letter": "Q", "frequency": 0.00095},
        {"letter": "R", "frequency": 0.05987},
        {"letter": "S", "frequency": 0.06327},
        {"letter": "T", "frequency": 0.09056},
        {"letter": "U", "frequency": 0.02758},
        {"letter": "V", "frequency": 0.00978},
        {"letter": "W", "frequency": 0.0236},
        {"letter": "X", "frequency": 0.0015},
        {"letter": "Y", "frequency": 0.01974},
        {"letter": "Z", "frequency": 0.00074}]


    return (
        <Container maxW={'5xl'} py={12}>
            <SimpleGrid columns={{base: 1, md: 2}} spacing={10}>
                <Stack spacing={4}>
                    <Text
                        textTransform={'uppercase'}
                        color={'blue.400'}
                        fontWeight={600}
                        fontSize={'sm'}
                        bg={useColorModeValue('blue.50', 'blue.900')}
                        p={2}
                        alignSelf={'flex-start'}
                        rounded={'md'}>
                        ABC company
                    </Text>
                    <Heading>Thống kê</Heading>
                    <Text color={'gray.500'} fontSize={'lg'}>
                        Thống kê cửa hàng của bạn trong ngày 06/07/2022
                    </Text>
                    <Stack
                        spacing={4}
                        divider={
                            <StackDivider
                                borderColor={useColorModeValue('gray.100', 'gray.700')}
                            />
                        }>
                        <Feature
                            icon={
                                <Icon as={IoAnalyticsSharp} color={'yellow.500'} w={5} h={5}/>
                            }
                            iconBg={useColorModeValue('yellow.100', 'yellow.900')}
                            text={'Doanh số bán theo loại'}
                            onClick={()=>{
                                getProducts()
                                setTypeChart(1)
                            }}
                        />
                        <Feature
                            icon={<Icon as={IoAnalyticsSharp} color={'green.500'} w={5} h={5}/>}
                            iconBg={useColorModeValue('green.100', 'green.900')}
                            text={'Tỉ lệ tồn kho'}
                            onClick={()=>setTypeChart(2)}
                        />
                        <Feature
                            icon={
                                <Icon as={IoAnalyticsSharp} color={'purple.500'} w={5} h={5}/>
                            }
                            iconBg={useColorModeValue('purple.100', 'purple.900')}
                            text={'Tỉ lệ khách hàng theo độ tuổi'}
                            onClick={()=>setTypeChart(3)}
                        />
                        <Feature
                            icon={
                                <Icon as={IoAnalyticsSharp} color={'blue.500'} w={5} h={5}/>
                            }
                            iconBg={useColorModeValue('blue.100', 'blue.900')}
                            text={'Tỉ lệ khách hàng theo giới tính'}
                            onClick={()=>setTypeChart(4)}
                        />
                    </Stack>
                </Stack>
                <Flex>
                    {typeChart === 0&&<Image
                        rounded={'md'}
                        alt={'feature image'}
                        src={
                            'https://images.unsplash.com/photo-1554200876-56c2f25224fa?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80'
                        }
                        objectFit={'cover'}
                    />}
                    {typeChart !== 0&&data.length>0&&<Chart
                        data={data}
                        type={typeChart}
                    />}
                </Flex>
            </SimpleGrid>
        </Container>
    );
}
