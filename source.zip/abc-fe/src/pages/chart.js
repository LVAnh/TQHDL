import * as d3 from 'd3'
import BarChart from "../components/bar-chart";

const Chart = ({data, type}) => {
    switch (type){
        case 1: return (
            <BarChart
                data={data}
                x={d => d.category_name}
                y={d => d.sales}
                xDomain={d3.groupSort(data, ([d]) => -d.sales, d => d.category_name)}
                yLabel={"↑ Doanh số"}
                width={window.innerWidth}
                height={window.innerHeight}
                color={"steelblue"}
            />
        )
        default: return (<div/>)

    }
}
export default Chart;
